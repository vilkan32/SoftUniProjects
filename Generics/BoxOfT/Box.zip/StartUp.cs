﻿using System;

namespace BoxOfT
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Box<int> asd = new Box<int>();

           
        }
    }
}
