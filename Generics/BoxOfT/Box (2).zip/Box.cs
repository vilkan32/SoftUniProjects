﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenericScale
{
    public class Box<T>
    {
        public  List<T> element;
        
        public Box()
        {
            this.element = new List<T>();
        }

        public void Add(T element)
        {
            this.element.Add(element);
        }

        public override string ToString()
        {
            return $"{typeof(T)}: {element}";
        }

        public void Swap(int firstIndex, int secondIndex)
        {
            var firstElement = this.element[firstIndex];
            this.element[firstIndex] = this.element[secondIndex];
            this.element[secondIndex] = firstElement;
        }

    }
}
