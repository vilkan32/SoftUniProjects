﻿using System;
using System.Linq;

namespace GenericScale
{
    class StartUp
    {
        static void Main(string[] args)
        {

            int n = int.Parse(Console.ReadLine());
            var box = new Box<string>();
            for (int i = 0; i < n; i++)
            {
                string inp = Console.ReadLine();
                box.Add(inp);
            }
            int[] swap = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

            box.Swap(swap[0], swap[1]);

            foreach (var item in box.element)
            {
                Console.WriteLine(item.ToString());
            }
        }
    }
}
