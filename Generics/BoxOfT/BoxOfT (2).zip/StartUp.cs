﻿using System;
using System.Linq;

namespace GenericScale
{
    class StartUp
    {
        static void Main(string[] args)
        {

            int n = int.Parse(Console.ReadLine());
            var box = new Box<string>();
            for (int i = 0; i < n; i++)
            {
                string inp = Console.ReadLine();
                box.Add(inp);
            }
            Console.WriteLine(box.CompareTo(Console.ReadLine()));
          
        }

        
    }
}
