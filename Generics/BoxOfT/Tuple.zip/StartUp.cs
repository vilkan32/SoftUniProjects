﻿using System;
using System.Linq;

namespace GenericScale
{
    class StartUp
    {
        static void Main(string[] args)
        {

            int n = int.Parse(Console.ReadLine());
            var box = new Box<double>();
            for (int i = 0; i < n; i++)
            {
                double inp = double.Parse(Console.ReadLine());
                box.Add(inp);
            }
            Console.WriteLine(box.CompareTo(double.Parse(Console.ReadLine())));
          
        }

        
    }
}
