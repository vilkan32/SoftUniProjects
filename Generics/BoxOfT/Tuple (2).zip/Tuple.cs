﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BoxOfT
{
    public class Tuple<T,C>
    {
        public T ItemOne { get; set; }
        public C ItemTwo { get; set; }
        
    }
}
