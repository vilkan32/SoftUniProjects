﻿using System;

namespace GenericScale
{
    class StartUp
    {
        static void Main(string[] args)
        {

            int n = int.Parse(Console.ReadLine());
            
            
            for (int i = 0; i < n; i++)
            {
                int inp = int.Parse(Console.ReadLine());
                var result = new Box<int>(inp);
                Console.WriteLine(result.ToString());

            }
           
        }
    }
}
