﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    public class NameBirthday : Children
    {
        public NameBirthday(string name, string birthday) : base(name, birthday)
        {

        }

    }
}
